class Account
{
    
        accid:number; 
      accname:string; 
       accbalance:number;
    constructor(accid:number,accname:string,accbalance:number)
    {
        this.accid=accid;
        this.accname=name;
        this.accbalance=accbalance;
    }

        getBalance():number
    {
        return this.accbalance;
    }

}

 class SavingAccount extends Account
{
    
    accinterest:number;
    constructor(accid,accname,accbalance,accinterest)
    {
        super(accid,accname,accbalance);
        this.accinterest=accinterest;
    }

    getBalance():number
    {
        return this.accbalance+this.accinterest;
    }


}

 class CurrentAccount extends Account
{
    acccash_credit:number;
     constructor(accid,accname,accbalance,acccash_credit)
    {
        super(accid,accname,accbalance);
        this.acccash_credit=acccash_credit;
    }


     getBalance():number
    {
        return this.accbalance+this.acccash_credit;
    }



}

let sa1 = new SavingAccount(101,"ash",1000,100);
let sa2 = new SavingAccount(106,"pqr",1000,100);
let sa3 = new SavingAccount(111,"abc",1000,100);
let ca1 = new CurrentAccount(111,"abc",1000,1000);
let ca2 = new CurrentAccount(145,"Sam",1000,1000);


var arr =[sa1,sa2,sa3,ca1,ca2];

//var alphas:Account[]; 
//alphas = [sa2,sa2,sa3,ca1,ca2] ;

let len:number;
len=arr.length;
console.log("Length",len);
    let totalBal=0;
    
    let i:number;

    for(i=0;i<len;i++)
    {
        totalBal+=arr[i].getBalance();

    }

console.log("Bank Bal: ",totalBal);





