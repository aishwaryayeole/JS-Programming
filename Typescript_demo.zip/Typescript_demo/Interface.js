var circle = {
    print: function () { return console.log("Circle printed "); }
};
var employee = {
    print: function () { return console.log("Employee Printed"); }
};
circle.print();
employee.print();
