var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Account = (function () {
    function Account(accid, accname, accbalance) {
        this.accid = accid;
        this.accname = name;
        this.accbalance = accbalance;
    }
    Account.prototype.getBalance = function () {
        return this.accbalance;
    };
    return Account;
}());
var SavingAccount = (function (_super) {
    __extends(SavingAccount, _super);
    function SavingAccount(accid, accname, accbalance, accinterest) {
        var _this = _super.call(this, accid, accname, accbalance) || this;
        _this.accinterest = accinterest;
        return _this;
    }
    SavingAccount.prototype.getBalance = function () {
        return this.accbalance + this.accinterest;
    };
    return SavingAccount;
}(Account));
var CurrentAccount = (function (_super) {
    __extends(CurrentAccount, _super);
    function CurrentAccount(accid, accname, accbalance, acccash_credit) {
        var _this = _super.call(this, accid, accname, accbalance) || this;
        _this.acccash_credit = acccash_credit;
        return _this;
    }
    CurrentAccount.prototype.getBalance = function () {
        return this.accbalance + this.acccash_credit;
    };
    return CurrentAccount;
}(Account));
var sa1 = new SavingAccount(101, "ash", 1000, 100);
var sa2 = new SavingAccount(106, "pqr", 1000, 100);
var sa3 = new SavingAccount(111, "abc", 1000, 100);
var ca1 = new CurrentAccount(111, "abc", 1000, 1000);
var ca2 = new CurrentAccount(145, "Sam", 1000, 1000);
var arr = [sa1, sa2, sa3, ca1, ca2];
//var alphas:Account[]; 
//alphas = [sa2,sa2,sa3,ca1,ca2] ;
var len;
len = arr.length;
console.log("Length", len);
var totalBal = 0;
var i;
for (i = 0; i < len; i++) {
    totalBal += arr[i].getBalance();
}
console.log("Bank Bal: ", totalBal);
