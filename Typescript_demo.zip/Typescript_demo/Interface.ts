function printall(obj):void{
let len:number;
len=obj.length;

    let i:number;

     for(i=0;i<len;i++)
    {
       obj[i].print();
    }

}


interface Printable{
print: ()=>void
}

let circle: Printable= {
print:()=>console.log("Circle printed ")
}

let employee:Printable = {
    print:()=> console.log("Employee Printed")
}

let obj =[circle,employee];



//printall(obj);

  


